name = 'iwaratool'
__version__ = '0.1.0'
__author__ = '白色羽毛|白羽'

from .iwara import iwaratool
